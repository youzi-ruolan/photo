import { defineStore } from 'pinia'
import { byId, templates } from '../lib/catalog.mjs'
import { cleanStyle } from '../lib/layout.mjs'

function read(key, fallback) {
  try { return uni.getStorageSync('imprint.' + key) || fallback }
  catch { return fallback }
}
function persist(key, value) {
  try { uni.setStorageSync('imprint.' + key, value) }
  catch { uni.showToast({title:'本机存储不可用，本次设置仍可使用',icon:'none'}) }
}
function savedIds(key) {
  const ids = read(key, [])
  if (!Array.isArray(ids)) return []
  return [...new Set(ids.filter(id => templates.some(item => item.id === id)))]
}
function savedFields() {
  const fields = read('fields', {})
  if (!fields || typeof fields !== 'object' || Array.isArray(fields)) return {}
  return Object.fromEntries(Object.entries(fields).filter(([,value]) => typeof value === 'string'))
}
export const useCamera = defineStore('camera', {
  state: () => ({
    selected: byId(read('selected','0-0')).id,
    favorites: savedIds('favorites'), recent: savedIds('recent').slice(0,12),
    fields: savedFields(), style: cleanStyle(read('style',{corner:read('corner','left')})),
    owned: false
  }),
  getters: {template: state => byId(state.selected)},
  actions: {
    select(id) {
      this.selected = byId(id).id
      persist('selected',this.selected)
      this.recent = [this.selected,...this.recent.filter(value => value !== this.selected)].slice(0,12)
      persist('recent',this.recent)
    },
    favorite(id) {
      this.favorites = this.favorites.includes(id) ? this.favorites.filter(value => value !== id) : [id,...this.favorites]
      persist('favorites',this.favorites)
    },
    edit(key,value) {
      this.fields = {...this.fields,[key]:Array.from(value.trim()).slice(0,48).join('')}
      persist('fields',this.fields)
    },
    setStyle(changes) {
      this.style = cleanStyle({...this.style,...changes})
      persist('style',this.style)
    }
  }
})
