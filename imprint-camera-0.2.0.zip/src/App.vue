<script setup>
import { onLaunch } from '@dcloudio/uni-app'
import { cloudEnv } from './lib/billing'
onLaunch(() => { if (cloudEnv && wx.cloud) wx.cloud.init({ env: cloudEnv }) })
</script>
<style>
page{background:#f6f3eb;color:#142e27;font-family:-apple-system,"PingFang SC",sans-serif;font-size:30rpx}view,button,input,scroll-view{box-sizing:border-box}button{background:transparent;color:inherit;font:inherit;margin:0;padding:0;line-height:1.4;border-radius:0}button::after{border:none}.page{padding:40rpx 32rpx calc(44rpx + env(safe-area-inset-bottom))}.heading{font-family:serif;font-size:58rpx;font-weight:700;letter-spacing:2rpx}.sub{font-size:24rpx;line-height:1.6;color:#56695d}.primary,.secondary{border-radius:16rpx;text-align:center;padding:24rpx;font-weight:600}.primary{background:#173f34;color:#fff8e7}.secondary{background:#e9e7da;color:#173f34}.row{display:flex;align-items:center;gap:18rpx}.spaced{justify-content:space-between}.muted{color:#62766c}.tag{font-size:20rpx;color:#885336;letter-spacing:1rpx}.thin{height:1px;background:#d8d9cd;margin:30rpx 0}
</style>
