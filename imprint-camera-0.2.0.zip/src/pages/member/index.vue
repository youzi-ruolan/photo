<template>
  <view class="page member">
    <view class="pass"><text class="pass-title">此刻专业版</text><text>全部水印模板，一次解锁</text><view class="lens"><view/><view/></view></view>
    <view class="row spaced plan"><text>一次买断</text><text class="price">¥{{price}}</text></view>
    <view class="benefit"><text>免费使用</text><text>20 款模板 · 拍摄与保存</text></view>
    <view class="benefit"><text>专业版增加</text><text>40 款模板 · 保存与分享</text></view>
    <view class="benefit"><text>换机恢复</text><text>同一微信账号</text></view>
    <view class="purchase">
      <text class="feedback" aria-live="polite">{{message}}</text>
      <button v-if="store.owned" class="primary" @tap="back">{{fromPhoto?'返回保存这张照片':'返回拍摄'}}</button>
      <button v-else-if="phase==='failed' || phase==='pending'" class="primary" :disabled="busy" @tap="refresh(true)">{{busy?'核对中…':'重新核对购买记录'}}</button>
      <button v-else class="primary" :disabled="busy || phase!=='available'" @tap="buy">{{buttonText}}</button>
      <view class="links"><button v-if="cloudEnv && !store.owned && phase!=='failed' && phase!=='pending'" :disabled="busy" @tap="refresh(true)">恢复购买</button><button v-if="!store.owned" :disabled="busy" @tap="useFree">选免费模板</button></view>
      <button v-if="phase==='failed' || phase==='pending'" class="help" open-type="feedback">反馈购买问题</button>
    </view>
    <view class="privacy"><text>照片在设备内处理。选择存草稿时，本机会保留一张。</text><view class="links"><button @tap="privacy">隐私保护指引</button><button open-type="feedback">使用反馈</button></view></view>
  </view>
</template>
<script setup>
import {computed,ref} from 'vue'
import {onLoad,onShow} from '@dcloudio/uni-app'
import {billing,cloudEnv,entitlement,login,pay} from '../../lib/billing'
import {useCamera} from '../../stores/camera'
const store=useCamera(),phase=ref(cloudEnv?'loading':'preview'),busy=ref(false),message=ref(''),price=ref('19.90'),fromPhoto=ref(false)
const buttonText=computed(()=>({preview:'开发预览 · 暂未开放购买',loading:'读取购买状态…',unsupported:'当前微信暂不可购买',paying:'正在确认订单…',available:'购买专业版　¥'+price.value}[phase.value] || '正在核对'))
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms))
const back=()=>uni.navigateBack()
function privacy(){
  if(typeof wx.openPrivacyContract==='function')wx.openPrivacyContract({fail:()=>uni.showToast({title:'暂未读取到平台隐私指引',icon:'none'})})
  else uni.showToast({title:'请在微信小程序信息页查看隐私指引',icon:'none'})
}
function useFree(){uni.redirectTo({url:'/pages/templates/index?free=1'})}
onLoad(o=>{fromPhoto.value=o?.from==='photo'})
async function sync(force){
  const status=await entitlement(force)
  store.owned=status.owned;price.value=(status.plan.price/100).toFixed(2)
  phase.value=status.enabled && typeof wx.requestVirtualPayment==='function'?'available':'unsupported'
  return status.owned
}
async function refresh(manual=false){
  if(!cloudEnv || busy.value)return
  busy.value=true
  try{
    const owned=await sync(manual)
    message.value=owned?'专业版已解锁':manual?'暂未查到已完成的购买记录':''
  }catch{phase.value='failed';message.value='网络暂时不可用。照片仍在，可以稍后再核对。'}
  finally{busy.value=false}
}
onShow(()=>refresh())
async function buy(){
  if(busy.value || phase.value!=='available' || store.owned)return
  busy.value=true;phase.value='paying';message.value=''
  try{
    const order=await billing('prepare',{code:await login()})
    if(!order.owned){
      await pay(order.payment)
      let owned=false
      for(const delay of [0,1000,2200]){await pause(delay);if(await sync(true)){owned=true;break}}
      if(!owned){phase.value='pending';message.value='微信返回支付成功，正在等待到账。请稍后核对订单。';return}
    }else{await sync(true)}
    message.value=store.owned?'购买已确认，返回即可使用':'请重新核对购买记录'
    if(!store.owned)phase.value='pending'
  }catch(e){
    if(/cancel/i.test(e.errMsg || '')){phase.value='available';message.value='已取消购买，你可以继续编辑照片。'}
    else{phase.value='failed';message.value='购买状态尚未确认，请先核对订单。'}
  }finally{busy.value=false}
}
</script>
<style scoped>
.member{min-height:100vh;background:#f6f6ef}.pass{position:relative;overflow:hidden;background:#173e32;color:#f4e8ce;padding:46rpx 36rpx;border-radius:24rpx;min-height:220rpx}.pass-title{display:block;font-family:serif;font-size:55rpx;margin-bottom:14rpx}.pass>text{position:relative;z-index:1}.lens,.lens view{position:absolute;border:2rpx solid #73846c;border-radius:50%}.lens{width:280rpx;height:280rpx;right:-135rpx;top:10rpx}.lens view:first-child{inset:22rpx}.lens view:last-child{inset:52rpx}.plan{margin:40rpx 0 18rpx;font-weight:600}.price{font-size:52rpx;color:#194832}.benefit,.links{display:flex;align-items:center;justify-content:space-between}.benefit{min-height:92rpx;border-bottom:1px solid #d8ded3;font-size:27rpx}.benefit text:last-child{color:#4f6656}.purchase{margin-top:44rpx}.feedback{display:block;font-size:25rpx;color:#455f50;line-height:1.6;margin-bottom:12rpx}.links{justify-content:center;gap:36rpx}.links button{min-height:48px;font-size:25rpx}.privacy{margin-top:38rpx;border-top:1px solid #d8ded3;padding-top:22rpx;font-size:23rpx;color:#586b5d;text-align:center}.help{min-height:44px;color:#456454;font-size:24rpx}.primary[disabled]{background:#e2e6d9;color:#526456}
</style>
