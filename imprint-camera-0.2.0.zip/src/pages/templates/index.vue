<template>
  <view class="catalog">
    <view class="filters">
      <view class="searchbox"><view class="magnify"/><input v-model="query" placeholder="搜时间、证件、旅行…" aria-label="搜索所有模板" maxlength="32" confirm-type="search" @input="searchAll"/><button v-if="query" aria-label="清空搜索" @tap="query=''">清除</button></view>
      <view class="sections"><button v-for="name in sections" :key="name" :class="{active:section===name}" @tap="activate(name)">{{name}}</button><button class="free-toggle" :aria-pressed="free" :class="{on:free}" @tap="free=!free">{{free?'✓ 仅免费':'仅免费'}}</button></view>
      <view class="filter-line"><button class="category" @tap="categoryOpen=!categoryOpen">{{category || '全部分类'}}　{{categoryOpen?'⌃':'⌄'}}</button><text>{{matches.length}} 款模板</text></view>
      <view v-if="categoryOpen" class="categories"><button v-for="name in categoryNames" :key="name" :class="{picked:category===name || (!category && name==='全部分类')}" @tap="pickCategory(name)">{{name}}</button></view>
    </view>
    <view v-if="matches.length" class="cards"><view v-for="item in shown" :key="item.id" class="card">
      <button class="photo" :aria-label="item.name+(item.pro?'，专业模板':'，免费模板')" @tap="choose(item)">
        <image :src="background(item.group)" mode="aspectFill" lazy-load/><image class="imprint" :src="'/static/thumbs/'+item.id+'.png'" mode="scaleToFill" lazy-load/>
        <text v-if="item.id===store.selected" class="inuse">使用中</text>
      </button>
      <view class="caption"><button class="choose" @tap="choose(item)"><text>{{item.name}}</text><text class="kind">{{item.category}} · {{item.pro?'专业':'免费'}}</text></button><button class="star" :class="{marked:store.favorites.includes(item.id)}" :aria-label="(store.favorites.includes(item.id)?'取消收藏':'收藏')+item.name" @tap="store.favorite(item.id)">{{store.favorites.includes(item.id)?'★':'☆'}}</button></view>
    </view></view>
    <button class="more" v-if="shown.length<matches.length" @tap="more">查看更多（剩余 {{matches.length-shown.length}} 款）</button>
    <view v-if="!matches.length" class="empty"><text>{{emptyTitle}}</text><button @tap="reset">看全部模板</button></view>
  </view>
</template>
<script setup>
import { computed,ref,watch } from 'vue'
import { onLoad,onReachBottom } from '@dcloudio/uni-app'
import { categories } from '../../lib/catalog.mjs'
import { findTemplates } from '../../lib/search.mjs'
import { useCamera } from '../../stores/camera'
const store=useCamera(), sections=['精选','收藏','最近'],categoryNames=['全部分类',...categories]
const section=ref('精选'),query=ref(''),category=ref(''),free=ref(false),categoryOpen=ref(false),limit=ref(12)
onLoad(options=>{free.value=options?.free==='1'})
const matches=computed(()=>findTemplates({section:section.value,category:category.value,query:query.value,free:free.value,recent:store.recent,favorites:store.favorites}))
const shown=computed(()=>matches.value.slice(0,limit.value))
const emptyTitle=computed(()=>query.value || category.value || free.value?'没有符合筛选条件的模板':section.value==='收藏'?'点模板旁的星标，把常用款放在这里':'选过的模板会出现在这里')
const photos=['sample','bicycle','lake','sample','tools','bicycle','paper','paper','lake','sample']
function background(group){return '/static/'+photos[group]+'.jpg'}
function more(){limit.value=Math.min(limit.value+12,matches.value.length)}
onReachBottom(more)
watch([section,query,category,free],()=>{limit.value=12;uni.pageScrollTo({scrollTop:0,duration:0})})
function activate(name){section.value=name;query.value='';category.value='';categoryOpen.value=false}
function pickCategory(name){category.value=name==='全部分类'?'':name;categoryOpen.value=false}
function searchAll(e){if(e.detail.value.trim()){section.value='精选';category.value='';categoryOpen.value=false}}
function reset(){activate('精选');free.value=false}
function choose(item){store.select(item.id);uni.navigateBack()}
</script>
<style scoped>
.catalog{min-height:100vh;padding-bottom:calc(28rpx + env(safe-area-inset-bottom));background:#f6f6ef;color:#16352a}
.filters{position:sticky;top:0;z-index:2;background:#f6f6ef;padding:22rpx 28rpx 0;border-bottom:1px solid #d5dcd1}
.searchbox,.sections,.filter-line,.caption{display:flex;align-items:center}.searchbox{gap:18rpx;background:#fff;border:1px solid #d6ddd1;border-radius:16rpx;padding:0 22rpx;min-height:46px}.searchbox input{flex:1;min-width:0;height:46px;font-size:27rpx}.searchbox button,.sections button,.category,.categories button{min-height:44px;font-size:25rpx}.magnify{width:25rpx;height:25rpx;border:3rpx solid #52675a;border-radius:100%;position:relative}.magnify::after{content:'';position:absolute;right:-7rpx;bottom:-5rpx;width:11rpx;height:3rpx;background:#52675a;transform:rotate(45deg)}
.sections{gap:24rpx;margin-top:12rpx}.sections button{color:#516b5b;min-width:44px}.sections .active{font-weight:700;color:#133b2d;border-bottom:4rpx solid #24583e}.sections .free-toggle{margin-left:auto;font-size:23rpx}.sections .on{font-weight:700;color:#17523c}.filter-line{justify-content:space-between}.filter-line text,.kind{font-size:22rpx;color:#50665a}.category{font-weight:600}.categories{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6rpx;padding-bottom:18rpx}.categories button{background:#e9efdf;border-radius:10rpx}.categories .picked{background:#193e2f;color:#f8f2df}
.cards{padding:24rpx 28rpx;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:26rpx 18rpx}.photo{display:block;position:relative;width:100%;height:210rpx;overflow:hidden;border-radius:14rpx;background:#e7e3d3}.photo image{width:100%;height:100%;display:block}.photo .imprint{position:absolute;inset:0}.inuse{position:absolute;top:8rpx;left:8rpx;padding:4rpx 10rpx;background:#17432f;color:white;border-radius:6rpx;font-size:19rpx}.caption{justify-content:space-between;gap:3rpx;padding-top:7rpx}.choose{text-align:left;flex:1;min-width:0;font-size:28rpx;font-weight:600;min-height:44px}.kind{display:block;font-weight:400;margin-top:3rpx}.star{width:44px;height:44px;color:#536b5d;font-size:38rpx}.marked{color:#89582d}.more,.empty button{padding:16rpx 26rpx;color:#194f38;min-height:44px;margin:auto}.empty{display:flex;align-items:center;flex-direction:column;gap:20rpx;padding:64rpx 24rpx;font-size:28rpx}.empty button{border:1px solid #8b9e8d;border-radius:16rpx}
</style>
