<template>
  <view class="camera-page">
    <view class="instrument">
      <template v-if="!source">
        <button class="top-action" :aria-label="'闪光灯'+flash" :disabled="busy" @tap="flash=flash==='off'?'on':'off'">闪光 {{flash==='off'?'关':'开'}}</button>
        <button class="top-action" :class="{lit:grid}" :aria-pressed="grid" @tap="grid=!grid">网格</button>
        <button class="top-action" :class="{lit:delaySeconds}" :disabled="busy" @tap="timerMenu">{{delaySeconds?delaySeconds+' 秒':'定时'}}</button>
      </template>
      <text v-else class="stage-title">{{saved?'已存相册':'成片预览'}}</text>
      <button v-if="draft && !source" class="top-action" :disabled="busy" @tap="draftMenu">草稿</button>
      <button class="account" :disabled="busy" @tap="member">{{store.owned?'已解锁':'专业版'}}</button>
    </view>
    <view id="finder" class="finder">
      <template v-if="!source && visible">
        <camera v-if="!cameraError" class="hardware" :device-position="device" :flash="flash" @initdone="ready=true" @error="cameraFailure">
          <cover-image v-if="overlay" class="overlay" :src="overlay"/>
          <cover-view v-if="remaining" class="countdown">{{remaining}}</cover-view>
        </camera>
        <view v-else class="fallback"><text class="fallback-title">从一张照片开始</text><text>{{cameraDenied?'开启相机权限即可拍摄，也可以先从相册选图。':'暂时没有可用的相机，可以先从相册选图。'}}</text><button class="rescue" @tap="album">从相册选图</button><button @tap="recover">{{cameraDenied?'打开相机设置':'重试相机'}}</button></view>
      </template>
      <image v-if="source" class="hardware" :src="result || source" mode="aspectFit" />
      <view v-if="source && renderError" class="render-status"><text>{{renderError}}</text><button @tap="schedule">重新生成</button></view>
    </view>
    <view class="dock">
      <template v-if="editing">
        <view class="editor-title"><text>编辑水印</text><button class="done" @tap="finishEdit">完成</button></view>
        <scroll-view scroll-y class="editor">
          <view v-if="fieldKey" class="text-row"><input v-model="draftText" :placeholder="store.template.input?.[1] || '相纸题字'" maxlength="48" :aria-label="fieldLabel" confirm-type="done" @confirm="finishEdit"/><text>{{draftText.length}}/48</text></view>
          <view v-if="store.template.group!==7" class="setting"><text>位置</text><view class="choices"><button v-for="item in corners" :key="item.id" :class="{selected:store.style.corner===item.id}" @tap="stylePick('corner',item.id)">{{item.name}}</button></view></view>
          <view class="setting"><text>字号</text><view class="choices"><button v-for="item in sizes" :key="item.id" :class="{selected:store.style.scale===item.id}" @tap="stylePick('scale',item.id)">{{item.name}}</button></view></view>
          <view class="setting"><text>浓度</text><view class="choices"><button v-for="item in opacities" :key="item.id" :class="{selected:store.style.opacity===item.id}" @tap="stylePick('opacity',item.id)">{{item.name}}</button></view></view>
        </scroll-view>
      </template>
      <template v-else>
        <view class="control-strip">
          <button class="template" :disabled="busy" @tap="templates"><text class="stack-icon"></text><text>{{store.template.name}}</text><text class="chevron">⌄</text></button>
          <button class="edit" :disabled="busy" @tap="edit">调水印</button>
          <button v-if="source && !saved" class="edit" :disabled="busy" @tap="keepDraft">存草稿</button>
        </view>
        <view v-if="!source" class="capture-controls">
          <button class="side" :disabled="busy" @tap="album"><view class="album-icon"><view/></view><text>相册</text></button>
          <button class="shutter" :class="{counting:remaining}" :aria-label="remaining?'取消倒计时':'拍摄照片'" :disabled="(!remaining && busy) || !ready" @tap="shutter"><view/></button>
          <button class="side" :disabled="busy" @tap="flip"><view class="flip-icon">↻</view><text>翻转</text></button>
        </view>
        <view v-else class="export">
          <button class="secondary" :disabled="busy" @tap="leavePhoto">{{saved?'继续拍摄':'返回拍摄'}}</button>
          <button v-if="saved && canShare" class="primary" :disabled="busy" @tap="share">分享照片</button>
          <button v-else class="primary" :disabled="saved || busy || !usable" @tap="save">{{busy?'处理中…':saved?'已保存':rendering?'生成中…':store.template.pro && !store.owned?'专业版保存':'保存到相册'}}</button>
        </view>
      </template>
    </view>
    <canvas id="studio" type="2d" class="canvas"/>
  </view>
</template>
<script setup>
import { ref,computed,watch,getCurrentInstance,nextTick } from 'vue'
import { onShow,onHide,onUnload,onReady,onResize } from '@dcloudio/uni-app'
import { useCamera } from '../../stores/camera'
import { inscription,needsValue } from '../../lib/catalog.mjs'
import { drawMark } from '../../lib/render.mjs'
import { corners,sizes,opacities,cleanStyle } from '../../lib/layout.mjs'
import { currentDraft,saveDraft,removeDraft,exists } from '../../lib/draft'
import { entitlement,cloudEnv } from '../../lib/billing'

const store=useCamera(), owner=getCurrentInstance().proxy
const visible=ref(true), ready=ref(false), cameraError=ref(false), cameraDenied=ref(false)
const busy=ref(false), rendering=ref(false), renderError=ref(''), usable=ref(false), saved=ref(false)
const source=ref(''), result=ref(''), overlay=ref(''), device=ref('back'), flash=ref('off'), grid=ref(false)
const editing=ref(false), draftText=ref(''), draft=ref(currentDraft()), remaining=ref(0), delaySeconds=ref(0)
const fieldKey=computed(()=>store.template.frame?'caption':store.template.input?store.template.field:'')
const fieldLabel=computed(()=>store.template.input?.[0] || '相纸题字')
const canShare=typeof wx.showShareImageMenu==='function'
let decodedPath=''
let canvas,viewSize,photo,stamp,imported=false,active=true,revision=0,lastClock='',drawing=false,recoveredPath=''
let clockTimer,countdownTimer,textTimer,resizeTimer
const toast=title=>uni.showToast({title,icon:'none'})
const templates=()=>uni.navigateTo({url:'/pages/templates/index'})
const member=()=>uni.navigateTo({url:'/pages/member/index?from='+ (source.value?'photo':'camera')})
function flip(){device.value=device.value==='back'?'front':'back'}
function cameraFailure(e){
  ready.value=false;cameraError.value=true
  cameraDenied.value=/auth|deny|denied|permission/i.test(e.detail?.errMsg || '')
  wx.getSetting({success:r=>{cameraDenied.value=r.authSetting['scope.camera']===false}})
  cancelCountdown()
}
function recover(){
  if(!cameraDenied.value){cameraError.value=false;return}
  uni.openSetting({success:r=>{if(r.authSetting['scope.camera']){cameraError.value=false;cameraDenied.value=false}}})
}
function timerMenu(){
  uni.showActionSheet({itemList:['关闭定时','3 秒后拍摄','10 秒后拍摄'],success:r=>{delaySeconds.value=[0,3,10][r.tapIndex]}})
}
function cancelCountdown(){
  clearInterval(countdownTimer)
  if(remaining.value)busy.value=false
  remaining.value=0
}
function shutter(){
  if(remaining.value)return cancelCountdown()
  if(!ready.value || busy.value)return
  busy.value=true
  if(!delaySeconds.value)return capture()
  remaining.value=delaySeconds.value
  countdownTimer=setInterval(()=>{
    remaining.value--
    if(!remaining.value){clearInterval(countdownTimer);capture()}
  },1000)
}
function edit(){
  draftText.value=store.fields[fieldKey.value] || ''
  editing.value=true
}
function finishEdit(){
  if(fieldKey.value && draftText.value.trim()!==(store.fields[fieldKey.value]||''))store.edit(fieldKey.value,draftText.value)
  clearTimeout(textTimer);editing.value=false
}
function stylePick(key,value){store.setStyle({[key]:value})}
watch(draftText,()=>{if(editing.value){clearTimeout(textTimer);textTimer=setTimeout(schedule,180)}})
function effectiveFields(){
  return editing.value && fieldKey.value ? {...store.fields,[fieldKey.value]:draftText.value.trim()} : store.fields
}
function discard(path){if(path)wx.getFileSystemManager().unlink({filePath:path,fail:()=>{}})}
function replace(target,path){
  const old=target.value;target.value=path
  if(old && old!==path)setTimeout(()=>discard(old),900)
}
function schedule(){
  revision++
  if(source.value){usable.value=false;saved.value=false;renderError.value=''}
  if(canvas && viewSize && active && !drawing)render()
}
function measure(){
  nextTick(()=>uni.createSelectorQuery().in(owner).select('#finder').boundingClientRect().exec(r=>{
    const rect=r?.[0]
    if(!rect?.width || !rect.height)return
    const changed=viewSize?.width!==rect.width || viewSize?.height!==rect.height
    viewSize=rect
    if(changed && (!source.value || (!usable.value && !drawing)))schedule()
  }))
}
watch(editing,measure)
onResize(()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(measure,70)})
function fetchImage(path){
  return new Promise((resolve,reject)=>{
    const image=canvas.createImage()
    image.onload=()=>resolve(image);image.onerror=reject;image.src=path
  })
}
async function decode(path){
  const info=await new Promise((resolve,reject)=>wx.getImageInfo({src:path,success:resolve,fail:reject}))
  const ratio=2304/Math.max(info.width,info.height)
  if(ratio>=1 || typeof wx.compressImage!=='function')return {image:await fetchImage(path),temp:''}
  const small=await new Promise((resolve,reject)=>wx.compressImage({src:path,quality:96,
    compressedWidth:Math.max(1,Math.round(info.width*ratio)),compressedHeight:Math.max(1,Math.round(info.height*ratio)),success:resolve,fail:reject}))
  const temp=small.tempFilePath!==path?small.tempFilePath:''
  try{return {image:await fetchImage(small.tempFilePath),temp}}
  catch(err){discard(temp);throw err}
}
function releasePhoto(){
  photo=null;discard(decodedPath);decodedPath=''
}
function guides(ctx,w,h){
  ctx.save();ctx.strokeStyle='rgba(255,255,255,.5)';ctx.lineWidth=1;ctx.beginPath()
  for(const n of [1,2]){ctx.moveTo(w*n/3,0);ctx.lineTo(w*n/3,h);ctx.moveTo(0,h*n/3);ctx.lineTo(w,h*n/3)}
  ctx.stroke();ctx.restore()
}
async function render(){
  if(drawing || !active || !canvas || !viewSize)return
  drawing=true;rendering.value=true
  const ticket=revision,path=source.value
  try{
    if(path && !photo){
      const decoded=await decode(path)
      if(ticket!==revision || source.value!==path || !active){discard(decoded.temp);return}
      photo=decoded.image;decodedPath=decoded.temp
    }
    const size=path?photo:viewSize
    const scale=path?Math.min(1,2304/Math.max(size.width,size.height)):Math.min(1,480/size.width)
    const w=Math.max(1,Math.round(size.width*scale)),h=Math.max(1,Math.round(size.height*scale))
    canvas.width=w;canvas.height=h
    const ctx=canvas.getContext('2d')
    ctx.clearRect(0,0,w,h)
    if(path)ctx.drawImage(photo,0,0,w,h)
    const lines=inscription(store.template,effectiveFields(),path?stamp:Date.now(),!!path && imported)
    if(!path && grid.value)guides(ctx,w,h)
    drawMark(ctx,w,h,store.template,lines,store.style.corner,store.style)
    const file=await new Promise((resolve,reject)=>wx.canvasToTempFilePath({canvas,fileType:path?'jpg':'png',quality:.94,
      success:r=>resolve(r.tempFilePath),fail:reject},owner.$scope))
    if(ticket!==revision || !active){discard(file);return}
    replace(path?result:overlay,file)
    if(path)usable.value=true
  }catch{
    if(ticket===revision && active && path)renderError.value='这张照片未能生成水印'
  }finally{
    drawing=false;rendering.value=false
    if(ticket!==revision && active)render()
  }
}
function openPhoto(path,albumPhoto,at=Date.now()){
  releasePhoto();source.value=path;stamp=at;imported=albumPhoto;ready.value=false
  recoveredPath='';replace(result,'');schedule()
}
function capture(){
  wx.createCameraContext().takePhoto({quality:'high',success:r=>openPhoto(r.tempImagePath,false),
    fail:()=>toast('拍摄失败，请重试'),complete:()=>{busy.value=false}})
}
function album(){
  if(busy.value)return
  busy.value=true
  wx.chooseMedia({count:1,mediaType:['image'],sourceType:['album'],sizeType:['original'],
    success:r=>openPhoto(r.tempFiles[0].tempFilePath,true),fail:r=>{if(!/cancel/.test(r.errMsg))toast('未能读取照片，请重试')},
    complete:()=>{busy.value=false}})
}
function closePhoto(){
  editing.value=false;source.value='';releasePhoto();recoveredPath='';saved.value=false
  usable.value=false;replace(result,'');ready.value=false;schedule();measure()
}
function leavePhoto(){
  if(saved.value)return closePhoto()
  uni.showModal({title:'离开这张照片？',content:'本次编辑尚未保存。你也可以先存为本机草稿。',
    confirmText:'离开',cancelText:'继续编辑',success:r=>{if(r.confirm)closePhoto()}})
}
async function keepDraft(){
  if(busy.value)return
  busy.value=true
  if(draft.value && draft.value.path!==recoveredPath){
    const ok=await new Promise(resolve=>uni.showModal({title:'替换上次的草稿？',content:'本机保留一张草稿。',confirmText:'替换',success:r=>resolve(r.confirm),fail:()=>resolve(false)}))
    if(!ok){busy.value=false;return}
  }
  try{
    draft.value=await saveDraft(source.value,{stamp,imported,template:store.selected,style:{...store.style},fields:{...store.fields}})
    closePhoto();toast('草稿已存到本机')
  }catch{toast('草稿保存失败，请检查剩余空间')}
  finally{busy.value=false}
}
function draftMenu(){
  const d=draft.value
  if(!d || busy.value)return
  uni.showActionSheet({itemList:['继续编辑草稿','删除本机草稿'],success:async r=>{
    if(r.tapIndex===1){
      uni.showModal({title:'删除这张草稿？',confirmText:'删除',success:async answer=>{if(answer.confirm){await removeDraft(d);draft.value=currentDraft()}}})
      return
    }
    if(!await exists(d.path)){await removeDraft(d);draft.value=null;toast('草稿文件已被清理');return}
    store.select(d.template);store.setStyle(cleanStyle(d.style))
    const key=fieldKey.value
    if(key)store.edit(key,d.fields?.[key] || '')
    openPhoto(d.path,d.imported,d.stamp);recoveredPath=d.path
  }})
}
async function save(){
  if(busy.value || !usable.value || saved.value)return
  if(needsValue(store.template,store.fields)){edit();toast('请先填写'+fieldLabel.value);return}
  busy.value=true
  const filePath=result.value,validAt=revision
  try{
    if(store.template.pro){
      if(!cloudEnv)return member()
      store.owned=(await entitlement()).owned
      if(!store.owned)return member()
    }
    if(validAt!==revision || !active)return
    await new Promise((resolve,reject)=>wx.saveImageToPhotosAlbum({filePath,success:resolve,fail:reject}))
    saved.value=true;toast('已保存到手机相册')
  }catch(e){
    if(/deny|denied|auth/i.test(e.errMsg||''))uni.showModal({title:'允许保存到相册',content:'在微信设置中开启相册写入权限后，可返回继续保存这张照片。',confirmText:'去设置',success:r=>{if(r.confirm)uni.openSetting({})}})
    else toast(e.message || '保存失败，请重试')
  }finally{busy.value=false}
}
function share(){
  if(saved.value && result.value && canShare)wx.showShareImageMenu({path:result.value,fail:e=>{if(!/cancel/i.test(e.errMsg||''))toast('可以从手机相册分享这张照片')}})
}
onReady(()=>{
  uni.createSelectorQuery().in(owner).select('#studio').fields({node:true}).exec(r=>{
    canvas=r[0]?.node
    if(!canvas){toast('画布初始化失败，请重新打开小程序');return}
    measure()
    if(viewSize)schedule()
  })
})
watch(()=>[store.selected,store.style,store.fields,grid.value],schedule)
onShow(()=>{
  active=true;visible.value=true;measure()
  if(!source.value || !usable.value)schedule()
  clearInterval(clockTimer)
  clockTimer=setInterval(()=>{
    if(source.value || !ready.value)return
    const lines=inscription(store.template,effectiveFields(),Date.now())
    const key=lines.title+lines.detail
    if(key!==lastClock){lastClock=key;schedule()}
  },1000)
})
onHide(()=>{active=false;visible.value=false;ready.value=false;clearInterval(clockTimer);cancelCountdown()})
onUnload(()=>{
  active=false;revision++;clearInterval(clockTimer);cancelCountdown();clearTimeout(textTimer);clearTimeout(resizeTimer)
  releasePhoto();discard(result.value);discard(overlay.value)
})
</script>
<style scoped>
.camera-page{height:100vh;display:flex;flex-direction:column;background:#102c26;color:#f2f2e4}
.instrument,.control-strip,.capture-controls,.editor-title,.setting,.choices,.export,.text-row{display:flex;align-items:center}
.instrument{min-height:92rpx;padding:0 20rpx;gap:4rpx}.instrument button,.edit,.done,.setting button{min-height:44px;font-size:25rpx;padding:0 14rpx}.instrument button,.edit{min-width:44px}.instrument .lit{color:#ffcc8f}.account{margin-left:auto;color:#f0c99b}.stage-title{padding-left:12rpx;font-size:27rpx;font-weight:600}
.finder{position:relative;flex:1;min-height:70px;overflow:hidden;background:#101b18}.hardware,.overlay{display:block;width:100%;height:100%}.countdown{position:absolute;top:40%;width:100%;text-align:center;font-size:108rpx;color:white}
.fallback{display:flex;height:100%;align-items:center;justify-content:center;flex-direction:column;gap:10rpx;padding:24rpx;text-align:center;font-size:24rpx;color:#cbd8ce}.fallback .fallback-title{font-size:39rpx;color:#f3eedc}.fallback button{min-height:44px;padding:12rpx 28rpx}.rescue{background:#ecd8b4;color:#18362c;border-radius:50rpx}.render-status{position:absolute;bottom:12rpx;left:16rpx;right:16rpx;background:#223c33;display:flex;align-items:center;justify-content:space-around;font-size:26rpx}.render-status button{min-height:44px}
.dock{padding:8rpx 28rpx calc(16rpx + env(safe-area-inset-bottom));background:#102c26}.control-strip{min-height:90rpx;gap:8rpx}.template{display:flex;align-items:center;gap:14rpx;padding:0 22rpx;min-height:44px;background:#29453a;border-radius:30rpx;font-size:28rpx}.edit{color:#dfe3d7}.control-strip .edit:first-of-type{margin-left:auto}.chevron{font-size:27rpx;color:#b7c4af}.stack-icon{width:22rpx;height:18rpx;border:2rpx solid #f4e3bf;box-shadow:-3rpx 3rpx #29453a,-5rpx 5rpx #f4e3bf}
.capture-controls{justify-content:space-around;padding-top:10rpx}.shutter{width:130rpx;height:130rpx;padding:7rpx;border:3rpx solid #e4b985;border-radius:100%}.shutter view{width:100%;height:100%;background:#fff0ce;border-radius:100%}.shutter.counting view{border-radius:8rpx;width:55%;height:55%;margin:auto;background:#e69769}.side{min-width:48px;min-height:48px;display:flex;align-items:center;flex-direction:column;justify-content:center;font-size:22rpx;gap:5rpx}.album-icon{width:36rpx;height:29rpx;border:3rpx solid #e6e5d4;border-radius:6rpx;overflow:hidden}.album-icon view{width:23rpx;height:23rpx;border:2rpx solid #e6e5d4;transform:rotate(45deg);margin:14rpx 0 0 7rpx}.flip-icon{font-size:44rpx;line-height:1}.export{gap:16rpx;padding:12rpx 0}.export button{flex:1;min-height:46px}.export .primary{background:#edd4a9;color:#143c2e}.export .secondary{background:#29473a;color:#f1edde}
.editor-title{justify-content:space-between;font-size:32rpx;font-weight:600}.done{color:#f5d09b}.editor{max-height:32vh}.setting,.text-row{justify-content:space-between;gap:12rpx;font-size:24rpx;color:#cddacb}.choices{gap:3rpx}.choices button{border-radius:10rpx;color:#cddacb;min-width:44px}.choices .selected{background:#d8ddbf;color:#1b342a}.text-row{background:#27453a;border-radius:12rpx;padding:0 18rpx;margin:6rpx 0}.text-row input{flex:1;min-width:0;height:48px;color:#fff3df;font-size:29rpx}.text-row text{font-size:21rpx}.canvas{position:fixed;left:-5000px;top:0;width:16px;height:16px;pointer-events:none}
@media(max-height:620px){.instrument{min-height:44px}.shutter{width:96rpx;height:96rpx}.dock{padding-top:0}.control-strip{min-height:44px}}
</style>
