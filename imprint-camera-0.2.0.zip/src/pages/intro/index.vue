<template><view class="intro"><image class="brand" src="/static/focus.gif" mode="widthFix"/><button class="enter" @tap="enter">进入相机　→</button></view></template>
<script setup>
import { onShow,onHide,onUnload } from '@dcloudio/uni-app'
let timer, leaving=false
function enter(){
  if(leaving) return
  leaving=true
  clearTimeout(timer)
  uni.redirectTo({url:'/pages/camera/index',success:()=>uni.setStorageSync('introSeen',true),fail:()=>{leaving=false}})
}
onShow(()=>{if(uni.getStorageSync('introSeen')) enter(); else timer=setTimeout(enter,1750)})
onHide(()=>clearTimeout(timer))
onUnload(()=>clearTimeout(timer))
</script>
<style scoped>
.intro{height:100vh;display:flex;align-items:center;justify-content:center;background:#102c26}.brand{width:84vw;max-width:440px}.enter{position:absolute;bottom:calc(58rpx + env(safe-area-inset-bottom));color:#e3e6d5;border:1px solid #667970;border-radius:50rpx;font-size:25rpx;padding:18rpx 32rpx}
</style>
