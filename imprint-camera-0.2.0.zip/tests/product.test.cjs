const {test}=require('node:test')
const assert=require('node:assert/strict')
const {coalesce}=require('../cloudfunctions/billing/coalesce')

test('同一实例按订单合并并发查单，失败后下一次可重试',async()=>{
  let calls=0
  const read=coalesce(async value=>{
    calls++
    await new Promise(resolve=>setImmediate(resolve))
    if(value==='fault')throw Error('provider unavailable')
    return value
  })
  const results=await Promise.all(Array.from({length:1000},()=>read('A','paid')))
  assert.equal(calls,1)
  assert.ok(results.every(value=>value==='paid'))
  await assert.rejects(read('A','fault'))
  assert.equal(await read('A','refunded'),'refunded')
  assert.equal(calls,3)
})
test('客户端权益缓存限时，支付返回强制查单，失败可以重试',async()=>{
  const {createEntitlements}=await import('../src/lib/entitlements.mjs')
  let clock=0,calls=0,owned=true,fail=false
  const read=createEntitlements(async()=>{calls++;if(fail)throw Error('offline');return {owned}},()=>clock)
  await Promise.all(Array.from({length:50},()=>read()))
  assert.equal(calls,1)
  owned=false;clock=29000
  assert.equal((await read()).owned,true)
  assert.equal((await read(true)).owned,false)
  clock=60000;fail=true;await assert.rejects(read())
  fail=false;assert.equal((await read()).owned,false);assert.equal(calls,4)
})
test('模板筛选、搜索、首屏去重和旧位置兼容',async()=>{
  const {findTemplates}=await import('../src/lib/search.mjs')
  const {cleanStyle}=await import('../src/lib/layout.mjs')
  const base={section:'精选',category:'',free:false,query:'',recent:[],favorites:[]}
  const all=findTemplates(base)
  assert.equal(new Set(all.map(t=>t.id)).size,60)
  assert.equal(findTemplates({...base,free:true}).length,20)
  assert.ok(findTemplates({...base,query:'维修'}).every(item=>item.group===4))
  assert.equal(findTemplates({...base,category:'边框装饰'}).length,6)
  assert.deepEqual(findTemplates({...base,section:'最近',recent:['2-1','0-0']}).map(t=>t.id),['2-1','0-0'])
  assert.deepEqual(cleanStyle({corner:'right'}),{corner:'right',opacity:1,scale:1})
})
test('极端长图的平铺次数有上限，拍立得四角排版均能完成',async()=>{
  const {drawMark}=await import('../src/lib/render.mjs')
  const {byId}=await import('../src/lib/catalog.mjs')
  let paints=0,stack=0
  const ctx=new Proxy({save(){stack++},restore(){stack--},measureText:text=>({width:text.length*12}),fillText(){paints++}},{get(o,k){return k in o?o[k]:()=>{}}})
  for(const [width,height] of [[1,2304],[2304,1],[640,480]]){
    paints=0;drawMark(ctx,width,height,byId('7-0'),{title:'仅供预览',detail:''},'right',{scale:0.78})
    assert.ok(paints>0 && paints<=1000);assert.equal(stack,0)
  }
  for(const corner of ['top-left','top-right','left','right']){
    drawMark(ctx,375,512,byId('8-3'),{title:'此刻留影',detail:'2026.11.18'},corner)
    assert.equal(stack,0)
  }
})
