const {test}=require('node:test')
const {readFileSync}=require('node:fs')
const {runInNewContext}=require('node:vm')
const crypto=require('node:crypto')
const {AsyncLocalStorage}=require('node:async_hooks')
const assert=require('node:assert/strict')
const {sign}=require('../cloudfunctions/billing/payment')

function service(){
  const docs=new Map(),counts={tokens:0,queries:0,deliveries:0}
  const identity=new AsyncLocalStorage()
  const user=()=>identity.getStore() || 'user'
  let txn=Promise.resolve(),remote,session,badToken=false
  const clone=value=>structuredClone(value)
  const collection=()=>({
    where:({_id})=>({limit:()=>({get:async()=>({data:docs.has(_id)?[clone(docs.get(_id))]:[]})})}),
    async add({data}){if(docs.has(data._id))throw Error('duplicate');docs.set(data._id,clone(data))},
    doc:id=>({get:async()=>({data:clone(docs.get(id))}),set:async({data})=>docs.set(id,clone({...data,_id:id}))})
  })
  const db={collection,runTransaction(fn){const next=txn.then(()=>fn({collection}));txn=next.catch(()=>{});return next}}
  const cloud={init(){},getWXContext:()=>({OPENID:user(),APPID:'app'}),database:()=>db}
  const env={MINI_APP_ID:'app',MINI_APP_SECRET:'secret',XPAY_PRODUCT_ID:'pro',XPAY_APP_KEY:'key',XPAY_OFFER_ID:'offer',XPAY_ENV:'1'}
  async function fetch(url,options){
    const path=new URL(url).pathname
    let json
    if(path==='/cgi-bin/stable_token'){counts.tokens++;json={access_token:'t'+counts.tokens,expires_in:7200}}
    else if(path==='/sns/jscode2session')json={openid:session || user(),session_key:'session'}
    else{
      assert.equal(new URL(url).searchParams.get('pay_sig'),sign('key',path+'&'+options.body))
      if(path==='/xpay/query_order'){
        counts.queries++
        await new Promise(resolve=>setImmediate(resolve))
        if(badToken){badToken=false;json={errcode:42001}}
        else json=remote?{order:clone(remote)}:{errcode:1,errmsg:'order not found'}
      }else{counts.deliveries++;json={errcode:0}}
    }
    return {ok:true,json:async()=>json}
  }
  const ctx={exports:{},process:{env},fetch,AbortSignal,URL,URLSearchParams,console:{error(){},info(){}},require:name=>name==='wx-server-sdk'?cloud:name==='node:crypto'?crypto:require('../cloudfunctions/billing/'+name)}
  runInNewContext(readFileSync(require.resolve('../cloudfunctions/billing/index'),'utf8'),ctx)
  return {call:(event,id)=>identity.run(id || 'user',()=>ctx.exports.main(event)),docs,counts,remote:r=>remote=r,session:id=>session=id,badToken:()=>badToken=true}
}
test('首次查权益、PENDING 重试、跨会话身份不匹配',async()=>{
  const s=service()
  assert.equal((await s.call({action:'status'})).owned,false);assert.equal(s.counts.queries,0)
  const results=await Promise.all(Array.from({length:50},()=>s.call({action:'prepare',code:'one'})))
  const numbers=new Set(results.map(r=>JSON.parse(r.payment.signData).outTradeNo))
  assert.equal(numbers.size,1);assert.equal(s.docs.size,1)
  s.session('different-user')
  assert.ok((await s.call({action:'prepare',code:'different'})).error)
})
test('付费回查、过期令牌重试、并发恢复和退款后复购',async()=>{
  const s=service()
  const first=await s.call({action:'prepare',code:'initial'})
  const number=JSON.parse(first.payment.signData).outTradeNo
  const remote={order_id:number,status:2,env_type:1,paid_time:1,order_fee:1990,paid_fee:1990,refund_fee:0,provide_time:0}
  s.remote(remote);s.badToken()
  const statuses=await Promise.all(Array.from({length:1000},()=>s.call({action:'status'})))
  assert.ok(statuses.every(s=>s.owned));assert.equal(s.counts.tokens,2);assert.equal(s.counts.queries,2);assert.equal(s.counts.deliveries,1)
  s.remote({...remote,refund_fee:1990,provide_time:1})
  assert.equal((await s.call({action:'status'})).owned,false)
  const renewed=await Promise.all(Array.from({length:10},()=>s.call({action:'prepare',code:'renew'})))
  const newNumbers=new Set(renewed.map(r=>JSON.parse(r.payment.signData).outTradeNo))
  assert.equal(newNumbers.size,1);assert.ok(!newNumbers.has(number));assert.equal(s.docs.size,2)
  assert.ok([...s.docs.values()].find(o=>o.refunded && o.number===number))
})

test('不同账号独立下单，免费账号不会查到他人订单',async()=>{
  const s=service()
  const orders=await Promise.all(['alice','bob'].map(user=>s.call({action:'prepare',code:'test'},user)))
  const numbers=orders.map(result=>JSON.parse(result.payment.signData).outTradeNo)
  assert.notEqual(numbers[0],numbers[1])
  s.remote({order_id:numbers[0],env_type:1,status:4,paid_time:1,order_fee:1990,paid_fee:1990,provide_time:1})
  assert.equal((await s.call({action:'status'},'alice')).owned,true)
  assert.ok((await s.call({action:'status'},'bob')).error)
  const initial=s.counts.queries
  const unpaid=await Promise.all(Array.from({length:1000},(_,n)=>s.call({action:'status'},'free'+n)))
  assert.ok(unpaid.every(r=>r.owned===false));assert.equal(s.counts.queries,initial)
})
