const {test}=require('node:test')
const assert=require('node:assert/strict')
const {readFileSync}=require('node:fs')
test('草稿替换：写入中断保留旧稿，成功后清理旧图，同一草稿重存不复制',async()=>{
  const files=new Set(),storage=new Map()
  let failIndex=false
  const fs={
    mkdir:o=>o.success(),
    access:o=>files.has(o.path)?o.success():o.fail(),
    copyFile:o=>{files.add(o.destPath);o.success()},
    unlink:o=>{files.delete(o.filePath);o.success()}
  }
  global.wx={env:{USER_DATA_PATH:'/private'},getStorageSync:k=>storage.get(k),
    setStorageSync:(k,v)=>{if(failIndex)throw Error('full');storage.set(k,v)},
    removeStorageSync:k=>storage.delete(k),getFileSystemManager:()=>fs,getImageInfo:o=>o.success({type:'png'})}
  const url='data:text/javascript;base64,'+readFileSync(require.resolve('../src/lib/draft.js')).toString('base64')
  const {saveDraft,currentDraft,removeDraft}=await import(url)
  const first=await saveDraft('/tmp/a',{stamp:123,template:'0-0'})
  assert.ok(first.path.endsWith('.png'))
  failIndex=true;await assert.rejects(saveDraft('/tmp/b',{stamp:456}));assert.deepEqual(currentDraft(),first)
  assert.equal(files.size,1)
  failIndex=false
  const next=await saveDraft('/tmp/c',{stamp:789})
  assert.ok(!files.has(first.path))
  assert.equal((await saveDraft(next.path,{stamp:790})).path,next.path)
  await removeDraft(first);assert.ok(currentDraft())
  await removeDraft(next);assert.equal(currentDraft(),null);assert.equal(files.size,0)
  delete global.wx
})
