const crypto=require('node:crypto')
function sign(secret,message){return crypto.createHmac('sha256',secret).update(message).digest('hex')}
function makePayment(config,order,sessionKey){
  const signData=JSON.stringify({offerId:config.offer,buyQuantity:1,env:config.env,currencyType:'CNY',productId:order.sku,goodsPrice:order.price,outTradeNo:order.number,attach:'studio_pro'})
  return {mode:'short_series_goods',signData,paySig:sign(config.key,'requestVirtualPayment&'+signData),signature:sign(sessionKey,signData)}
}
function paidFor(remote,order,env){
  return !!remote && remote.order_id===order.number && remote.env_type!=null && Number(remote.env_type)===env &&
    [2,3,4].includes(Number(remote.status)) && Number(remote.paid_time)>0 &&
    Number(remote.order_fee)===order.price && Number(remote.paid_fee)===order.price &&
    Number(remote.refund_fee || 0)===0
}
module.exports={sign,makePayment,paidFor}
