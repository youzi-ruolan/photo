// Node 18+ 微信云函数。所有商品参数、订单归属和发货判断均在服务端处理。
const cloud=require('wx-server-sdk')
const crypto=require('node:crypto')
const {sign,makePayment,paidFor}=require('./payment')
const {coalesce}=require('./coalesce')
cloud.init({env:cloud.DYNAMIC_CURRENT_ENV})
const db=cloud.database()
let tokenCache
function config(){
  const e=process.env
  return {appId:e.MINI_APP_ID,secret:e.MINI_APP_SECRET,key:e.XPAY_APP_KEY,offer:e.XPAY_OFFER_ID,
    sku:e.XPAY_PRODUCT_ID,price:Number(e.XPAY_PRICE_FEN || 1990),env:Number(e.XPAY_ENV ?? 1)}
}
function failedAt(stage,code){
  const err=new Error('微信服务暂时未确认结果')
  err.stage=stage
  if(Number.isFinite(Number(code)))err.providerCode=Number(code)
  return err
}
async function request(url,options){
  const response=await fetch(url,{...options,signal:AbortSignal.timeout(8000)})
  if(!response.ok)throw failedAt(new URL(url).pathname,response.status)
  return response.json()
}
const fetchToken=coalesce(async c=>{
  const r=await request('https://api.weixin.qq.com/cgi-bin/stable_token',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({grant_type:'client_credential',appid:c.appId,secret:c.secret})})
  if(!r.access_token)throw failedAt('token',r.errcode)
  tokenCache={value:r.access_token,expires:Date.now()+(r.expires_in-120)*1000}
  return tokenCache.value
})
function credential(c){
  if(tokenCache && tokenCache.expires>Date.now())return tokenCache.value
  return fetchToken(c.appId,c)
}
async function xpay(c,path,data){
  const body=JSON.stringify(data)
  const url=new URL(path,'https://api.weixin.qq.com')
  const token=await credential(c)
  url.searchParams.set('access_token',token)
  url.searchParams.set('pay_sig',sign(c.key,path+'&'+body))
  const options={method:'POST',headers:{'Content-Type':'application/json'},body}
  const first=await request(url,options)
  if(![40014,42001].includes(first.errcode))return first
  if(tokenCache?.value===token)tokenCache=null
  url.searchParams.set('access_token',await credential(c))
  return request(url,options)
}
function accountKey(c,openid){
  return crypto.createHash('sha256').update([c.appId,c.env,c.offer,c.sku,openid].join('|')).digest('hex').slice(0,32)
}
async function lookup(id){
  const result=await db.collection('imprint_orders').where({_id:id}).limit(1).get()
  return result.data[0] || null
}
async function createOrder(id,c,openid){
  const order={_id:id,openid,sku:c.sku,price:c.price,number:crypto.randomBytes(14).toString('hex'),issuedAt:Date.now()}
  try{await db.collection('imprint_orders').add({data:order});return order}
  catch(err){const existing=await lookup(id);if(existing)return existing;throw err}
}
const inspect=coalesce(async(order,c)=>{
  const response=await xpay(c,'/xpay/query_order',{openid:order.openid,env:c.env,order_id:order.number})
  if(response.errcode){
    if(/order.*(not.exist|not.found)|订单不存在|未找到订单/i.test(response.errmsg || ''))return {owned:false}
    throw failedAt('query_order',response.errcode)
  }
  const remote=response.order
  if(!remote || remote.order_id!==order.number || remote.env_type==null || Number(remote.env_type)!==c.env)throw new Error('订单身份未确认')
  if(!paidFor(remote,order,c.env)){
    if(Number(remote.paid_fee)>0 && Number(remote.refund_fee)===Number(remote.paid_fee))return {owned:false,refunded:true}
    if(Number(remote.paid_time)>0)throw new Error('款项需进一步核对')
    return {owned:false}
  }
  if(!Number(response.order.provide_time)){
    const notify=await xpay(c,'/xpay/notify_provide_goods',{env:c.env,order_id:order.number})
    if(notify.errcode)throw failedAt('notify_provide_goods',notify.errcode)
  }
  return {owned:true}
})
async function renewRefunded(order,c){
  const number=crypto.randomBytes(14).toString('hex')
  // 退款已由微信确认。历史快照和新订单在同一事务中落库，竞争请求复用胜出的订单。
  return db.runTransaction(async transaction=>{
    const collection=transaction.collection('imprint_orders')
    const current=(await collection.doc(order._id).get()).data
    if(current.number!==order.number)return current
    const archiveId='r'+order.number
    const {_id,...record}=current
    await collection.doc(archiveId).set({data:{...record,archivedAt:Date.now(),refunded:true}})
    const next={...record,number,price:c.price,issuedAt:Date.now()}
    await collection.doc(_id).set({data:next})
    return {...next,_id}
  })
}
exports.main=async(event={})=>{
  const c=config(),identity=cloud.getWXContext()
  const enabled=!!(identity.OPENID && identity.APPID===c.appId && c.secret && c.key && c.offer && c.sku && [0,1].includes(c.env) && Number.isSafeInteger(c.price) && c.price>0)
  const base={plan:{price:Number.isSafeInteger(c.price)?c.price:1990},enabled,owned:false}
  if(!enabled)return event.action==='status'?base:{error:'支付服务尚未配置完成'}
  if(!['status','prepare'].includes(event.action))return {error:'操作无效'}
  const started=Date.now()
  try{
    const id=accountKey(c,identity.OPENID)
    let order=await lookup(id)
    const state=order?await inspect(order.number,order,c):{owned:false}
    const {owned}=state
    if(order && !state.refunded)base.plan.price=order.price
    if(owned || event.action==='status')return {...base,owned}
    if(typeof event.code!=='string' || !event.code || event.code.length>256)return {error:'请重新登录微信'}
    const params=new URLSearchParams({appid:c.appId,secret:c.secret,grant_type:'authorization_code',js_code:event.code})
    const session=await request('https://api.weixin.qq.com/sns/jscode2session?'+params)
    if(session.openid!==identity.OPENID || !session.session_key)return {error:'微信登录已过期，请重试'}
    if(state.refunded)order=await renewRefunded(order,c)
    order=order || await createOrder(id,c,identity.OPENID)
    return {...base,payment:makePayment(c,order,session.session_key)}
  }catch(err){
    console.error(JSON.stringify({event:'billing_error',action:event.action,type:err.name,stage:err.stage,providerCode:err.providerCode,elapsedMs:Date.now()-started}))
    return {error:'订单暂未确认，请稍后重试或恢复购买'}
  }finally{
    if(Date.now()-started>1500)console.info(JSON.stringify({event:'billing_slow',action:event.action,elapsedMs:Date.now()-started}))
  }
}
