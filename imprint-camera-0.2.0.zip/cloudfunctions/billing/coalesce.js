// 仅合并同一云函数实例内尚未完成的相同请求，不缓存用户支付结果。
function coalesce(work) {
  const running = new Map()
  return (key,...args) => {
    if (!running.has(key)) {
      const job = Promise.resolve().then(() => work(...args)).finally(() => running.delete(key))
      running.set(key,job)
    }
    return running.get(key)
  }
}
module.exports={coalesce}
